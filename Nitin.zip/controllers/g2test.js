module.exports = (req, res) => {
  console.log("G2Test Route | ", userObject);
  res.render("g2test");
};
