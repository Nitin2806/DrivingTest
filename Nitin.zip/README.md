# DrivingTest
This is my college Project

## Instruction to run this project
### Clone the project 
Open the directory and enter the command "npm i". This will install all necessary libraries
